"""
Client Supabase pour Hilo POC.

Toutes les opérations DB passent par ici.
Utilise la lib `supabase-py`.
"""

import os
from datetime import datetime, timezone
from typing import Optional
from supabase import create_client, Client


# ============================================
# Client Supabase
# ============================================
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")

_client: Optional[Client] = None


def get_client() -> Client:
    global _client
    if _client is None:
        if not SUPABASE_URL or not SUPABASE_SERVICE_KEY:
            raise RuntimeError("SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY doivent être configurés")
        _client = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)
    return _client


def get_tenant_id_from_slug(slug: str) -> str:
    """Récupère l'UUID d'un tenant à partir de son slug."""
    client = get_client()
    resp = client.table("tenants").select("id").eq("slug", slug).execute()
    if not resp.data:
        raise ValueError(f"Tenant '{slug}' introuvable")
    return resp.data[0]["id"]


# ============================================
# Leads
# ============================================
def get_or_create_lead(
    tenant_slug: str,
    sender: dict,
    channel: str,
    profile: dict,
) -> dict:
    """
    Recherche ou crée un lead à partir des infos sender Chatwoot.
    """
    client = get_client()
    tenant_id = get_tenant_id_from_slug(tenant_slug)

    # Identifiant externe (Chatwoot contact ID)
    chatwoot_contact_id = str(sender.get("id", ""))
    sender_name = sender.get("name", "unknown")

    # Recherche : existe-t-il déjà un lead avec ce chatwoot_contact_id ?
    existing = (
        client.table("leads")
        .select("*")
        .eq("tenant_id", tenant_id)
        .contains("external_ids", {"chatwoot_contact_id": chatwoot_contact_id})
        .execute()
    )

    if existing.data:
        # Mise à jour last_interaction
        lead = existing.data[0]
        client.table("leads").update({
            "last_interaction_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", lead["id"]).execute()
        return lead

    # Création : générer nouveau lead_id
    lead_id_str = generate_next_lead_id(tenant_id)

    new_lead = {
        "tenant_id": tenant_id,
        "lead_id": lead_id_str,
        "name": sender_name,
        "source": profile.get("source", "instagram"),
        "language": profile.get("language", "ES"),
        "contact_type": profile.get("type", "curieux"),
        "produit_interet": "vista-serena-terrain",
        "qualification": profile.get("qualification", "cold"),
        "next_step": "Suivi",
        "is_attributable_ig": profile.get("source") in ["instagram", "whatsapp"],
        "external_ids": {"chatwoot_contact_id": chatwoot_contact_id},
    }

    resp = client.table("leads").insert(new_lead).execute()
    return resp.data[0]


def generate_next_lead_id(tenant_id: str) -> str:
    """Génère le prochain lead_id format L-YYYY-NNN."""
    client = get_client()
    year = datetime.now().year
    prefix = f"L-{year}-"

    # Trouver le max existant pour cette année et ce tenant
    resp = (
        client.table("leads")
        .select("lead_id")
        .eq("tenant_id", tenant_id)
        .like("lead_id", f"{prefix}%")
        .order("lead_id", desc=True)
        .limit(1)
        .execute()
    )

    if not resp.data:
        return f"{prefix}001"

    last_id = resp.data[0]["lead_id"]
    last_num = int(last_id.split("-")[-1])
    return f"{prefix}{(last_num + 1):03d}"


# ============================================
# Conversations
# ============================================
def save_conversation(
    tenant_slug: str,
    lead_id: str,
    chatwoot_conv_id: int,
    channel: str,
) -> dict:
    client = get_client()
    tenant_id = get_tenant_id_from_slug(tenant_slug)

    # Vérifier si conversation existe déjà
    existing = (
        client.table("conversations")
        .select("*")
        .eq("tenant_id", tenant_id)
        .eq("chatwoot_conversation_id", chatwoot_conv_id)
        .execute()
    )

    if existing.data:
        return existing.data[0]

    new_conv = {
        "tenant_id": tenant_id,
        "lead_id": lead_id,
        "channel": channel,
        "chatwoot_conversation_id": chatwoot_conv_id,
        "status": "open",
    }
    resp = client.table("conversations").insert(new_conv).execute()
    return resp.data[0]


# ============================================
# Messages
# ============================================
def save_message(
    tenant_slug: str,
    conversation_id: str,
    direction: str,
    sender_type: str,
    content: str,
    chatwoot_message_id: Optional[int] = None,
    metadata: Optional[dict] = None,
) -> dict:
    client = get_client()
    tenant_id = get_tenant_id_from_slug(tenant_slug)

    new_msg = {
        "tenant_id": tenant_id,
        "conversation_id": conversation_id,
        "direction": direction,
        "sender_type": sender_type,
        "content": content,
        "chatwoot_message_id": chatwoot_message_id,
        "metadata": metadata or {},
    }
    resp = client.table("messages").insert(new_msg).execute()
    return resp.data[0]


# ============================================
# Drafts
# ============================================
def save_draft(
    tenant_slug: str,
    conversation_id: str,
    triggered_by_message_id: str,
    original_draft: str,
    hilo_analysis: dict,
) -> dict:
    client = get_client()
    tenant_id = get_tenant_id_from_slug(tenant_slug)

    new_draft = {
        "tenant_id": tenant_id,
        "conversation_id": conversation_id,
        "triggered_by_message_id": triggered_by_message_id,
        "original_draft": original_draft,
        "hilo_analysis": hilo_analysis,
        "status": "pending",
    }
    resp = client.table("drafts").insert(new_draft).execute()
    return resp.data[0]


def mark_draft_sent(draft_id: str, sent_version: str, edit_diff: str = "") -> dict:
    client = get_client()
    resp = (
        client.table("drafts")
        .update({
            "sent_version": sent_version,
            "edit_diff": edit_diff,
            "status": "sent",
            "sent_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", draft_id)
        .execute()
    )
    return resp.data[0]


# ============================================
# Audit log
# ============================================
def log_audit(
    tenant_slug: str,
    actor: str,
    action: str,
    entity_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    before_data: Optional[dict] = None,
    after_data: Optional[dict] = None,
) -> dict:
    client = get_client()
    tenant_id = get_tenant_id_from_slug(tenant_slug)

    entry = {
        "tenant_id": tenant_id,
        "actor": actor,
        "action": action,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "before_data": before_data,
        "after_data": after_data,
    }
    resp = client.table("audit_log").insert(entry).execute()
    return resp.data[0]
