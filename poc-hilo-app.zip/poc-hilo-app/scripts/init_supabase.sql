-- Hilo POC — Schéma Supabase initial
-- Multi-tenant PostgreSQL avec row-level security

-- ============================================
-- Table : tenants
-- ============================================
CREATE TABLE IF NOT EXISTS tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  config JSONB NOT NULL DEFAULT '{}',
  canonical_version TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- Table : leads
-- ============================================
CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id TEXT NOT NULL,  -- format L-YYYY-NNN
  name TEXT,
  country TEXT,
  source TEXT NOT NULL,
  language TEXT,
  contact_type TEXT,
  produit_interet TEXT,
  lot_specifique TEXT,
  qualification TEXT NOT NULL DEFAULT 'cold',
  budget_indicatif TEXT,
  next_step TEXT DEFAULT 'Suivi',
  is_attributable_ig BOOLEAN NOT NULL DEFAULT FALSE,
  notes TEXT,
  first_contact_at TIMESTAMPTZ DEFAULT NOW(),
  last_interaction_at TIMESTAMPTZ DEFAULT NOW(),
  external_ids JSONB DEFAULT '{}',  -- { "instagram_id": "...", "chatwoot_contact_id": "..." }
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(tenant_id, lead_id)
);

CREATE INDEX idx_leads_tenant ON leads(tenant_id);
CREATE INDEX idx_leads_qualification ON leads(tenant_id, qualification);
CREATE INDEX idx_leads_external_ids ON leads USING GIN (external_ids);

-- ============================================
-- Table : conversations
-- ============================================
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id UUID REFERENCES leads(id) ON DELETE SET NULL,
  channel TEXT NOT NULL,  -- 'instagram_dm', 'whatsapp', 'email', 'ig_comment'
  chatwoot_conversation_id BIGINT,
  status TEXT DEFAULT 'open',  -- open, resolved, pending
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_conversations_tenant ON conversations(tenant_id);
CREATE INDEX idx_conversations_chatwoot ON conversations(chatwoot_conversation_id);

-- ============================================
-- Table : messages
-- ============================================
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  direction TEXT NOT NULL,  -- 'inbound' | 'outbound'
  sender_type TEXT NOT NULL,  -- 'lead' | 'agent' | 'hilo'
  content TEXT NOT NULL,
  chatwoot_message_id BIGINT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_messages_conv ON messages(conversation_id);
CREATE INDEX idx_messages_tenant ON messages(tenant_id, created_at);

-- ============================================
-- Table : drafts (proposés par Hilo)
-- ============================================
CREATE TABLE IF NOT EXISTS drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  triggered_by_message_id UUID REFERENCES messages(id),
  original_draft TEXT NOT NULL,  -- version proposée par Hilo
  sent_version TEXT,  -- version effectivement envoyée (peut différer)
  status TEXT DEFAULT 'pending',  -- pending | edited | sent | discarded
  hilo_analysis JSONB DEFAULT '{}',  -- profil détecté, langue, sources, RED FLAGS
  edit_diff TEXT,  -- diff textuel entre original_draft et sent_version
  created_at TIMESTAMPTZ DEFAULT NOW(),
  sent_at TIMESTAMPTZ
);

CREATE INDEX idx_drafts_conv ON drafts(conversation_id);
CREATE INDEX idx_drafts_status ON drafts(tenant_id, status);

-- ============================================
-- Table : audit_log (RGPD + traçabilité)
-- ============================================
CREATE TABLE IF NOT EXISTS audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  actor TEXT NOT NULL,  -- email de l'agent ou 'hilo-service' ou 'chatwoot-webhook'
  action TEXT NOT NULL,  -- 'lead_created', 'draft_generated', 'message_sent', etc.
  entity_type TEXT,  -- 'lead' | 'draft' | 'message'
  entity_id UUID,
  before_data JSONB,
  after_data JSONB,
  ip_address INET,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_tenant ON audit_log(tenant_id, created_at DESC);

-- ============================================
-- Seed initial : tenant Vista Serena
-- ============================================
INSERT INTO tenants (slug, name, config, canonical_version)
VALUES (
  'vista-serena',
  'Vista Serena Miches',
  '{
    "langues_supportees": ["ES", "EN", "FR"],
    "voice_charter": {
      "max_emojis": 1,
      "default_formality": "vouvoiement",
      "signature": "François\nVista Serena — Miches, R.D."
    },
    "sources_canoniques": ["instagram", "whatsapp", "google_ads", "seo_organic", "referral", "email", "direct"],
    "qualifications": ["cold", "warm", "hot", "vendu", "perdu"],
    "produits_interet": ["vista-serena-terrain", "talipot-vefa", "les-deux", "autre"]
  }',
  '1.1.4'
) ON CONFLICT (slug) DO NOTHING;

-- ============================================
-- Trigger : auto-update updated_at
-- ============================================
CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at_leads BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

CREATE TRIGGER set_updated_at_conversations BEFORE UPDATE ON conversations
  FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

CREATE TRIGGER set_updated_at_tenants BEFORE UPDATE ON tenants
  FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
